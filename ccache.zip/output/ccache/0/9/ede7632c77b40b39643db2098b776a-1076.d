build-standard/extmod/modopenamp_remoteproc_store.o: \
 ../../extmod/modopenamp_remoteproc_store.c /usr/include/stdc-predef.h
