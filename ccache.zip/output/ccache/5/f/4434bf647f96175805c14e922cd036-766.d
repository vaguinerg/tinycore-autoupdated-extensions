build-standard/extmod/mbedtls/mbedtls_alt.o: \
 ../../extmod/mbedtls/mbedtls_alt.c /usr/include/stdc-predef.h
