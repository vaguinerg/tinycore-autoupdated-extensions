build-standard/py/asmarm.o: ../../py/asmarm.c /usr/include/stdc-predef.h \
 /usr/include/stdio.h /usr/include/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stddef.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdarg.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/bits/stdio.h \
 /usr/include/assert.h /usr/include/string.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/strings.h ../../py/mpconfig.h mpconfigport.h \
 /usr/include/time.h /usr/include/bits/time.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h /usr/include/unistd.h \
 /usr/include/bits/posix_opt.h /usr/include/bits/environments.h \
 /usr/include/bits/confname.h /usr/include/bits/getopt_posix.h \
 /usr/include/bits/getopt_core.h /usr/include/bits/unistd_ext.h \
 variants/standard/mpconfigvariant.h \
 variants/standard/../mpconfigvariant_common.h /usr/include/alloca.h \
 /usr/include/sched.h /usr/include/bits/sched.h \
 /usr/include/bits/types/struct_sched_param.h /usr/include/bits/cpu-set.h
