build-standard/lib/mbedtls/library/ssl_cookie.o: \
 ../../lib/mbedtls/library/ssl_cookie.c /usr/include/stdc-predef.h \
 ../../lib/mbedtls/library/common.h \
 ../../lib/mbedtls/include/mbedtls/build_info.h \
 mbedtls/mbedtls_config_port.h \
 ../../extmod/mbedtls/mbedtls_config_common.h ../../py/mpconfig.h \
 mpconfigport.h /usr/include/time.h /usr/include/features.h \
 /usr/include/features-time64.h /usr/include/bits/wordsize.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stddef.h \
 /usr/include/bits/time.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/unistd.h /usr/include/bits/posix_opt.h \
 /usr/include/bits/environments.h /usr/include/bits/confname.h \
 /usr/include/bits/getopt_posix.h /usr/include/bits/getopt_core.h \
 /usr/include/bits/unistd_ext.h variants/standard/mpconfigvariant.h \
 variants/standard/../mpconfigvariant_common.h /usr/include/alloca.h \
 /usr/include/stdio.h /usr/include/bits/libc-header-start.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdarg.h \
 /usr/include/bits/types/__fpos_t.h /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/sched.h \
 /usr/include/bits/sched.h /usr/include/bits/types/struct_sched_param.h \
 /usr/include/bits/cpu-set.h \
 ../../lib/mbedtls/include/mbedtls/config_adjust_legacy_crypto.h \
 ../../lib/mbedtls/include/mbedtls/config_adjust_x509.h \
 ../../lib/mbedtls/include/mbedtls/config_adjust_ssl.h \
 ../../lib/mbedtls/include/mbedtls/check_config.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/limits.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/posix1_lim.h \
 /usr/include/bits/local_lim.h /usr/include/linux/limits.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/pthread_stack_min.h /usr/include/bits/posix2_lim.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-intn.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h ../../lib/mbedtls/library/alignment.h \
 /usr/include/string.h /usr/include/strings.h /usr/include/stdlib.h \
 /usr/include/bits/waitflags.h /usr/include/bits/waitstatus.h \
 /usr/include/sys/types.h /usr/include/endian.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/bits/stdlib-float.h \
 /usr/include/assert.h ../../lib/mbedtls/include/mbedtls/platform.h \
 ../../lib/mbedtls/include/mbedtls/private_access.h \
 ../../lib/mbedtls/include/mbedtls/platform_time.h \
 /usr/include/inttypes.h ../../lib/mbedtls/include/mbedtls/ssl_cookie.h \
 ../../lib/mbedtls/include/mbedtls/ssl.h \
 ../../lib/mbedtls/include/mbedtls/platform_util.h \
 ../../lib/mbedtls/include/mbedtls/bignum.h \
 ../../lib/mbedtls/include/mbedtls/ecp.h \
 ../../lib/mbedtls/include/mbedtls/ssl_ciphersuites.h \
 ../../lib/mbedtls/include/mbedtls/pk.h \
 ../../lib/mbedtls/include/mbedtls/md.h \
 ../../lib/mbedtls/include/mbedtls/rsa.h \
 ../../lib/mbedtls/include/mbedtls/ecdsa.h \
 ../../lib/mbedtls/include/mbedtls/cipher.h \
 ../../lib/mbedtls/include/mbedtls/x509_crt.h \
 ../../lib/mbedtls/include/mbedtls/x509.h \
 ../../lib/mbedtls/include/mbedtls/asn1.h \
 ../../lib/mbedtls/include/mbedtls/x509_crl.h \
 ../../lib/mbedtls/include/mbedtls/ecdh.h \
 ../../lib/mbedtls/include/psa/crypto.h \
 ../../lib/mbedtls/include/psa/crypto_platform.h \
 ../../lib/mbedtls/include/psa/build_info.h \
 ../../lib/mbedtls/include/psa/crypto_types.h \
 ../../lib/mbedtls/include/psa/crypto_values.h \
 ../../lib/mbedtls/include/psa/crypto_sizes.h \
 ../../lib/mbedtls/include/psa/crypto_struct.h \
 ../../lib/mbedtls/include/psa/crypto_driver_contexts_primitives.h \
 ../../lib/mbedtls/include/psa/crypto_driver_common.h \
 ../../lib/mbedtls/include/psa/crypto_sizes.h \
 ../../lib/mbedtls/include/psa/crypto_builtin_primitives.h \
 ../../lib/mbedtls/include/mbedtls/md5.h \
 ../../lib/mbedtls/include/mbedtls/ripemd160.h \
 ../../lib/mbedtls/include/mbedtls/sha1.h \
 ../../lib/mbedtls/include/mbedtls/sha256.h \
 ../../lib/mbedtls/include/mbedtls/sha512.h \
 ../../lib/mbedtls/include/mbedtls/sha3.h \
 ../../lib/mbedtls/include/psa/crypto_driver_contexts_composites.h \
 ../../lib/mbedtls/include/psa/crypto_builtin_composites.h \
 ../../lib/mbedtls/include/mbedtls/cmac.h \
 ../../lib/mbedtls/include/mbedtls/chachapoly.h \
 ../../lib/mbedtls/include/mbedtls/poly1305.h \
 ../../lib/mbedtls/include/mbedtls/chacha20.h \
 ../../lib/mbedtls/include/mbedtls/ecjpake.h \
 ../../lib/mbedtls/include/psa/crypto_driver_contexts_key_derivation.h \
 ../../lib/mbedtls/include/psa/crypto_builtin_key_derivation.h \
 ../../lib/mbedtls/include/psa/crypto_extra.h \
 ../../lib/mbedtls/include/psa/crypto_compat.h \
 ../../lib/mbedtls/library/ssl_misc.h \
 ../../lib/mbedtls/include/mbedtls/error.h \
 ../../lib/mbedtls/library/ssl_ciphersuites_internal.h \
 ../../lib/mbedtls/library/x509_internal.h \
 ../../lib/mbedtls/library/pk_internal.h \
 ../../lib/mbedtls/include/mbedtls/constant_time.h
