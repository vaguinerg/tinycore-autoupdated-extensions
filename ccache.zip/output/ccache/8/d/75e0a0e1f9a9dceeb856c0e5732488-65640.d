build-standard/lib/berkeley-db-1.xx/btree/bt_page.o: \
 ../../lib/berkeley-db-1.xx/btree/bt_page.c /usr/include/stdc-predef.h \
 /usr/include/sys/types.h /usr/include/features.h \
 /usr/include/features-time64.h /usr/include/bits/wordsize.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/time_t.h /usr/include/bits/types/timer_t.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stddef.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/stdio.h \
 /usr/include/bits/libc-header-start.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdarg.h \
 /usr/include/bits/types/__fpos_t.h /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/bits/stdio.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/db.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/limits.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/posix1_lim.h \
 /usr/include/bits/local_lim.h /usr/include/linux/limits.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/pthread_stack_min.h /usr/include/bits/posix2_lim.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/config.h \
 ../../extmod/berkeley-db/berkeley_db_config_port.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/filevtable.h \
 /usr/include/unistd.h /usr/include/bits/posix_opt.h \
 /usr/include/bits/environments.h /usr/include/bits/confname.h \
 /usr/include/bits/getopt_posix.h /usr/include/bits/getopt_core.h \
 /usr/include/bits/unistd_ext.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/compat.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/btree.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/mpool.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/bsd-queue.h \
 ../../lib/berkeley-db-1.xx/include/berkeley-db/btree_extern.h
