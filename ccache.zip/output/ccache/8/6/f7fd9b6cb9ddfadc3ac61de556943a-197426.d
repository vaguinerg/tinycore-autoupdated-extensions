build-standard/extmod/modcryptolib.o: ../../extmod/modcryptolib.c \
 /usr/include/stdc-predef.h ../../py/mpconfig.h mpconfigport.h \
 /usr/include/time.h /usr/include/features.h \
 /usr/include/features-time64.h /usr/include/bits/wordsize.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stddef.h \
 /usr/include/bits/time.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/unistd.h /usr/include/bits/posix_opt.h \
 /usr/include/bits/environments.h /usr/include/bits/confname.h \
 /usr/include/bits/getopt_posix.h /usr/include/bits/getopt_core.h \
 /usr/include/bits/unistd_ext.h variants/standard/mpconfigvariant.h \
 variants/standard/../mpconfigvariant_common.h /usr/include/alloca.h \
 /usr/include/stdio.h /usr/include/bits/libc-header-start.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdarg.h \
 /usr/include/bits/types/__fpos_t.h /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/sched.h \
 /usr/include/bits/sched.h /usr/include/bits/types/struct_sched_param.h \
 /usr/include/bits/cpu-set.h /usr/include/assert.h /usr/include/string.h \
 /usr/include/strings.h ../../py/runtime.h ../../py/mpstate.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-intn.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h ../../py/mpthread.h mpthreadport.h \
 /usr/include/pthread.h /usr/include/bits/pthreadtypes.h \
 /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/bits/setjmp.h \
 /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct___jmp_buf_tag.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/pthread_stack_min.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/stdbool.h \
 ../../py/misc.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/limits.h \
 /usr/local/lib/gcc/x86_64-pc-linux-gnu/14.2.0/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/posix1_lim.h \
 /usr/include/bits/local_lim.h /usr/include/linux/limits.h \
 /usr/include/bits/posix2_lim.h build-standard/genhdr/compressed.data.h \
 ../../py/nlr.h ../../py/obj.h ../../py/qstr.h \
 build-standard/genhdr/qstrdefs.generated.h ../../py/mpprint.h \
 ../../py/runtime0.h ../../py/objlist.h ../../py/objexcept.h \
 ../../py/objtuple.h build-standard/genhdr/root_pointers.h \
 ../../py/pystack.h ../../py/cstack.h \
 ../../lib/mbedtls/include/mbedtls/aes.h \
 ../../lib/mbedtls/include/mbedtls/private_access.h \
 ../../lib/mbedtls/include/mbedtls/build_info.h \
 mbedtls/mbedtls_config_port.h \
 ../../extmod/mbedtls/mbedtls_config_common.h \
 ../../lib/mbedtls/include/mbedtls/config_adjust_legacy_crypto.h \
 ../../lib/mbedtls/include/mbedtls/config_adjust_x509.h \
 ../../lib/mbedtls/include/mbedtls/config_adjust_ssl.h \
 ../../lib/mbedtls/include/mbedtls/check_config.h \
 ../../lib/mbedtls/include/mbedtls/platform_util.h \
 ../../lib/mbedtls/include/mbedtls/platform_time.h \
 /usr/include/inttypes.h
