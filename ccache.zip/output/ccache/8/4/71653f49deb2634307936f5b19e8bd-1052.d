build-standard/extmod/modopenamp_remoteproc.o: \
 ../../extmod/modopenamp_remoteproc.c /usr/include/stdc-predef.h
