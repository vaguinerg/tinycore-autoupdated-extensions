build-standard/extmod/modopenamp.o: ../../extmod/modopenamp.c \
 /usr/include/stdc-predef.h
